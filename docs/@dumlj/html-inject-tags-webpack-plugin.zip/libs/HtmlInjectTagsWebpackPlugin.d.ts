import { HtmlEnhanceWebpackPlugin, type HtmlEnhanceWebpackPluginOptions } from '@dumlj/html-enhance-webpack-plugin';
import type { Compiler } from 'webpack';
/** Tag 属性 */
export type TagAttrs = Record<string, string | boolean>;
/**
 * Tag 位置
 * @description
 * 这里跟随 HtmlWebpackPlugin 输出，所以只有前后
 */
export type TagLocation = 'prepend' | 'append';
/** Tag 配置 */
export interface TagProps {
    url?: string;
    attrs?: TagAttrs;
    content?: string;
    location?: TagLocation;
}
export interface HtmlInjectTagsWebpackPluginOptions extends HtmlEnhanceWebpackPluginOptions {
    /** Script Tag 配置集合 */
    scriptTags?: Array<string | TagProps>;
    /** Link Tag 配置集合 */
    styleTags?: Array<string | TagProps>;
    /** Meta Tag 配置集合 */
    metaTags?: Array<Omit<TagProps, 'url' | 'content'>>;
}
export declare class HtmlInjectTagsWebpackPlugin extends HtmlEnhanceWebpackPlugin {
    static PLUGIN_NAME: string;
    scriptTags: Array<string | TagProps>;
    styleTags: Array<string | TagProps>;
    metaTags: Array<Omit<TagProps, 'url' | 'content'>>;
    constructor(options?: HtmlInjectTagsWebpackPluginOptions);
    /** 统一 Tag 属性 */
    protected unifiedTagProps(props: string | TagProps, defaultAttrs?: TagAttrs): TagProps;
    /** 注入 Tags */
    applyInjectTags(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
