/// <reference types="node" />
import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { IncomingMessage, ServerResponse } from 'http';
import type { Compiler } from 'webpack';
export interface Client {
    id: string;
    res: ServerResponse;
}
export interface CrxLiveReloadWebpackPluginParams {
    host?: string;
    port?: number;
    liveloadServer?: string;
}
export interface CrxLiveReloadWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** filename of background.js for chrome extension, default background.js */
    background?: string;
    /** filename of contentScript.js for chrome extension, default contentScript.js */
    contentScript?: string;
    backgroundLiveReloadScript?: string;
    contentScriptReloadScript?: string;
}
export declare class CrxLiveReloadWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected clients: Client[];
    protected host: string;
    protected port: number;
    protected liveloadServer: string;
    protected background: string;
    protected contentScript: string;
    protected backgroundLiveReloadScript: string;
    protected contentScriptLiveReloadScript: string;
    constructor(params?: CrxLiveReloadWebpackPluginParams, options?: CrxLiveReloadWebpackPluginOptions);
    /** 重写 DevServer */
    applyOverrideDevServer(compiler: Compiler): void;
    /** 注入模块 */
    applyLiveReloadInject(compiler: Compiler): void;
    /** 注册服务 */
    applyLiveReloadSender(compiler: Compiler): void;
    /** 序列化通信数据 */
    protected serializeMessage(data: any): string;
    /** 发送消息 */
    protected sendMessage(message: any): void;
    /** 头部返回值 */
    protected withCros(callback: (req: IncomingMessage, res: ServerResponse) => void): (req: IncomingMessage, res: ServerResponse) => void;
    apply(compiler: Compiler): void;
}
