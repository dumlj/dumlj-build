/** 后台默认文件名 */
export declare const BACKGROUND_DEFAULT_FILE = "background.js";
/** 弹框默认文件名 */
export declare const POPUP_DEFAULT_FILE = "popup.html";
/** 注入页面脚本默认文件名 */
export declare const CONTENT_SCRIPT_DEFAULT_FILE = "contentScript.js";
export declare const BACKGROUND_LIVERELOAD_SCRIPT_DEFAULT_FILE: string;
export declare const CONTENT_SCRIPT_LIVERELOAD_SCRIPT_DEFAULT_FILE: string;
