/** 当前 SID */
export declare const SSE_SESSION_ID: string;
/** SSE 重载标识 */
export declare const SSE_RELOAD_TOKEN = "reload";
/** SSE 服务路径 */
export declare const SSE_SERVER_PATH = "__livereload__";
/** 头部信息 */
export declare const SSE_HEADERS: {
    'Content-Type': string;
    Connection: string;
    'Cache-Control': string;
};
