/** 心跳 */
export declare const HEART_BEAT = "HEART_BEAT";
/** 重载 */
export declare const LIVERELOAD = "LIVERELOAD";
/** 日志 */
export declare const LOG = "LOG";
