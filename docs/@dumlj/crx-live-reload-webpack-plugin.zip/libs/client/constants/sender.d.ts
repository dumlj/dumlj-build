/** 标识 */
export declare const LIVERELOAD_MESSAGE_TARGET = "livereload";
