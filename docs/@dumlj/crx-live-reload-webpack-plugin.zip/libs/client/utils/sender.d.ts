/// <reference types="chrome" />
export interface MessageRequestOptions {
    quiet?: boolean;
}
export interface MessageRequest<T = any> {
    target: string;
    action: string;
    payload?: T;
    options?: MessageRequestOptions;
}
export interface MessageResponse<T = any> {
    code: number;
    success: boolean;
    message: string;
    data?: T;
}
export type MessageHandle<T = any> = (payload: T, sender: chrome.runtime.MessageSender) => void;
/** 是否为 livereload 信息 */
export declare const isLiveReloadMessage: <T = any>(request: MessageRequest<T>) => boolean;
/** 接收信息 */
export declare const onRuntimeMessage: <T = any>(action: string, handler: MessageHandle<T>) => void;
/** 发送信息 */
export declare function sendRuntimeMessage<T = any, R = any>(action: string, payload?: T, options?: MessageRequestOptions): Promise<R>;
/** 向 Tab 发送信息 */
export declare function sendTabMessage<T = any, R = any>(tab: number, action: string, payload?: T, options?: MessageRequestOptions): Promise<R>;
export interface BroadcastTabsOptions {
    tabs?: number[];
}
/** 广播 Tab 消息 */
export declare const broadcastTabs: <T = any>(action: string, payload?: T, options?: BroadcastTabsOptions) => Promise<unknown>;
