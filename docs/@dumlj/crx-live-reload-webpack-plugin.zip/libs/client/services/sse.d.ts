/** 重载 */
export declare const reload: () => void;
/** 启动 */
export declare const sse: () => void;
export default sse;
