export interface LogMessage {
    type: 'ok' | 'info' | 'warn' | 'fail' | 'debug';
    message: string;
}
export declare const ok: (message: string) => void;
export declare const info: (message: string) => void;
export declare const warn: (message: string) => void;
export declare const fail: (message: string) => void;
export declare const debug: (message: string) => void;
