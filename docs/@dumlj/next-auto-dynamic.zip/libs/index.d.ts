import type { NextConfig } from 'next';
import { type NextDynamicClientWebpackPluginOptions } from './NextDynamicClientWebpackPlugin';
export declare function nextDynamicClient(options?: NextDynamicClientWebpackPluginOptions): (nextConfig: NextConfig) => NextConfig;
