import type { VirtualBuilder } from './types';
export declare const DYNAMIC_FILE_SUFFIX = ".dynamic-client-virtual";
export declare const VIRTUAL_MODULE_RENDER: VirtualBuilder;
