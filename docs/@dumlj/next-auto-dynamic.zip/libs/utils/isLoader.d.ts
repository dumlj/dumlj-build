import type { Loader } from '../types';
export declare function isLoader(target: Record<string, any>): target is Loader;
