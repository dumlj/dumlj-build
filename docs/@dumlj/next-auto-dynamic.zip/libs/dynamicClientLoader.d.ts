import type { LoaderContext } from 'webpack';
export interface DynamicClientLoaderOptions {
    getVirtualModules(): Map<string, string>;
}
export default function dynamicClientLoader(this: LoaderContext<DynamicClientLoaderOptions>, source: string): string | undefined;
