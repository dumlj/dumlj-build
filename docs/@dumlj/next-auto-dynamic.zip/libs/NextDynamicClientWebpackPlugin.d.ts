import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import { type Compiler } from 'webpack';
import type { VirtualBuilder, Loader, FilenameParts } from './types';
export declare const LOADER_PATH: string;
export interface NextDynamicClientWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 目标文件夹 */
    src: string | string[];
    /** 默认值为 .dynamic-client-virtual */
    suffix?: string;
    /** 包含文件 */
    include?: string | string[];
    /** 过滤文件 */
    exclude?: string | string[];
    /** 渲染虚拟模块 */
    renderVirtualModule?: VirtualBuilder;
    /** loaders */
    loaders?: Loader | Loader[];
}
export declare class NextDynamicClientWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected src: string[];
    protected include: string[];
    protected exclude: string[];
    protected suffix: string;
    /** key 为源文件绝对路径 */
    protected virtualModules: Map<string, string>;
    protected renderVirtualModule: VirtualBuilder;
    protected loaders: Loader[];
    constructor(options?: NextDynamicClientWebpackPluginOptions);
    apply(compiler: Compiler): void;
    protected applyReplacement(compiler: Compiler): void;
    protected applyVirtualModules(compiler: Compiler): void;
    protected disassembleFilename(file: string): {
        folder: string;
        stem: string;
        extname: string;
    };
    protected assembleFilename(parts: FilenameParts): string;
    protected getVirtualFile(file: string): string;
    protected isVirtualFile(file: string): boolean;
    protected filterFiles(files: string[]): string[];
}
