declare const __GLOBAL_TARGET__: string;
declare const __GLOBAL_PROP_FN__: string;
declare const __GLOBAL_PROP_NAME__: string;
