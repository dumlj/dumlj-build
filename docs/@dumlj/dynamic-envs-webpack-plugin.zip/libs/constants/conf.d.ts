/** Global variables that store environment variables */
export declare const GLOBAL_TARGET = "Object";
/** The definition module of getting environments method */
export declare const FIND_ENV_MODULE: string;
