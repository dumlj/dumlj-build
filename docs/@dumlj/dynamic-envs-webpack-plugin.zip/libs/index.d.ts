import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler, WebpackPluginInstance } from 'webpack';
export interface DynamicEnvsWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 存储环境变量的全局变量 */
    globalThis?: string;
    /** 获取环境变量所在全局变量的方法名称 */
    globalThisFn?: string;
    /** 环境变量存储在全局变量中的名称 */
    globalThisProp?: string;
    /** 脚本路径 */
    scriptPath?: string;
}
export declare class DynamicEnvsWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    variables: Record<string, any>;
    protected globalThis: string;
    protected globalThisProp: string;
    protected globalThisFn: string;
    /**
     * 脚本路径
     * @description
     * 特殊入口需要用到，例如 workbox
     */
    scriptPath: string;
    /**
     * 是否已经注入
     * @description
     * 因为 DefinePlugin 动态无法修改环境变量
     * 因此只要提示一次，且触发一次注入即可
     */
    private injected;
    constructor(envs?: Record<string, any>, options?: DynamicEnvsWebpackPluginOptions);
    protected spwanCompile(compiler: Compiler, scriptPath: string, plugins: WebpackPluginInstance[]): string;
    /** inject env getter scripts to entries */
    applyInjectEnvGetterScript(compiler: Compiler): void;
    /** inject variables by webpack define plugin */
    applyVariables(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
