export declare const makeGetEnvFnRenderer: (globalThisFn: string, globalThis?: string) => ([]: TemplateStringsArray, key: string, value?: any) => string;
