export interface PushScriptToEntriesOptions {
    /** 位于另一个入口文件之后 */
    after?: string;
}
export declare const pushScriptToEntries: (scriptPath: string, options?: PushScriptToEntriesOptions) => <T>(entries: T) => T;
