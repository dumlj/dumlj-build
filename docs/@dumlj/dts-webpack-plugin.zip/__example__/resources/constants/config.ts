export const MESSAGE = 'hello world'
