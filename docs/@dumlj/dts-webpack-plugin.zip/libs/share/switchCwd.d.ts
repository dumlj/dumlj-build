/** 切换执行路径 */
export declare const switchCwd: (cwd: string, callback: (...args: any[]) => any) => any;
