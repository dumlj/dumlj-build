import { type CompilerOptions } from 'typescript';
export interface CompileDTSOptions {
    /** 执行目录 */
    cwd?: string;
    /** 根目录相对于 tsconfig.json 中的 compilerOptions.rootDir */
    rootDir?: string;
}
/** 编译 dts 文件 */
export declare const compileDTS: (files: string[], compileOptions: CompilerOptions, options?: CompileDTSOptions) => {};
