/** 为声明项目重命名 */
export declare const renameForTypesProject: (name: string) => string;
