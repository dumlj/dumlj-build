export interface MakeTsConfigOptions {
    /** 支持 ts 别名 */
    supportAlias?: boolean;
}
export declare const makeTsConfig: (tsconfig: Record<string, any>, options?: MakeTsConfigOptions) => {
    compilerOptions: any;
};
