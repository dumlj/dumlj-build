import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface DtsWebpackPluginOptions extends SeedWebpackPluginOptions {
    /**
     * 输出的文件夹
     * @description
     * 默认为 typings
     */
    output?: string;
    /**
     * 根目录相
     * @description
     * 默认读取 tsconfig.json 中的 compilerOptions.rootDir
     */
    rootDir?: string;
    /**
     * 类型输出文件夹
     * @description
     * - 默认读取 tsconfig.json 中的 compilerOptions.declarationDir。
     * - 实际路径是 output + declarationDir + filename
     * - 只针对类型
     */
    declarationDir?: string;
    /** tsconfig 配置文件 */
    tsconfig?: string;
    /** 忽略文件 */
    ignore?: string[];
    /** 支持 ts 别名 */
    supportAlias?: boolean;
    /**
     * 是否生成文件信息
     * @description
     * 默认开启
     */
    emitStats?: boolean;
    /**
     * 是否生成项目
     * @description
     * 默认开启
     */
    emitProject?: boolean;
    /**
     * 是否生成压缩包
     * @description
     * 默认关闭
     */
    emitTgz?: boolean;
}
export declare class DtsWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected output: string;
    protected rootDir: string;
    protected declarationDir?: string;
    protected tsconfig: string;
    protected ignore: string[];
    protected supportAlias?: boolean;
    protected emitStats?: boolean;
    protected emitProject?: boolean;
    protected emitTgz?: boolean;
    /** 文件 */
    protected tsFiles: Set<string>;
    constructor(options?: DtsWebpackPluginOptions);
    /**
     * 预安装 ts-patch
     * 这里要使用到
     * @see https://github.com/nonara/ts-patch#setup
     */
    applyPreinstallTsPatch(compiler: Compiler): void;
    /** 收集 .ts 文件 */
    applyCollectTsFiles(compiler: Compiler): void;
    /** 执行编译 */
    applyCompile(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
