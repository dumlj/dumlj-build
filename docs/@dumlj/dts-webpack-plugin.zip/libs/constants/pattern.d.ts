export declare const FUNC_STYLE = "(?:\\b(?:import|require)\\s*\\(\\s*(\\/\\*.*\\*\\/\\s*)?(?:[\"'][^\"'\r\n]+[\"'])\\s*\\))";
export declare const GLOBAL_STYLE = "(?:\\bimport\\s+(?:[\"'][^\"'\r\n]+[\"']))";
export declare const FROM_STYLE = "(?:\\bfrom\\s+(?:[\"'][^\"'\r\n]+[\"']))";
export declare const MODULE_STYLE = "(?:\\bmodule\\s+(?:[\"'][^\"'\r\n]+[\"']))";
export declare const IMPORT_REGEX_STRING: string;
