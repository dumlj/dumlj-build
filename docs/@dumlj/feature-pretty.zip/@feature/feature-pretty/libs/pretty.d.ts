import type { Options } from './types';
/** 基础着色函数 */
export declare const pretty: (info: string | Error, options?: Options) => {
    message: string;
    reason: Error;
    prettyMessage: string;
};
