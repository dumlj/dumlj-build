/** 通用配置 */
export interface Options {
    /** 前缀信息 */
    prefix?: string;
    /** 展示所有详情 */
    verbose?: boolean;
}
