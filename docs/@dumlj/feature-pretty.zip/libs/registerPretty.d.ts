import { type Color } from 'chalk';
import type { Options } from './types';
/** 注册着色函数配置 */
export interface RegisterPrettyOptions {
    /** 只展示在"展示详情"的情况下 */
    onlyShowInVerbose?: boolean;
    /** 前缀信息 */
    prefix?: string;
    /** 展示详情 */
    verbose?: boolean;
}
/** 注册着色函数 */
export declare const registerPretty: (color: typeof Color, registerOptions?: RegisterPrettyOptions) => (info: string | Error, options?: Options) => {
    message: string;
    reason: Error;
    prettyMessage: string;
};
