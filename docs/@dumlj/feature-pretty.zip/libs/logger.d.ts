/** 调试 */
export declare const debug: (info: string | Error, options?: import("./types").Options | undefined) => {
    message: string;
    reason: Error;
    prettyMessage: string;
};
/** 成功 */
export declare const ok: (info: string | Error, options?: import("./types").Options | undefined) => {
    message: string;
    reason: Error;
    prettyMessage: string;
};
/** 信息 */
export declare const info: (info: string | Error, options?: import("./types").Options | undefined) => {
    message: string;
    reason: Error;
    prettyMessage: string;
};
/** 警告 */
export declare const warn: (info: string | Error, options?: import("./types").Options | undefined) => {
    message: string;
    reason: Error;
    prettyMessage: string;
};
/** 错误 */
export declare const fail: (info: string | Error, options?: import("./types").Options | undefined) => {
    message: string;
    reason: Error;
    prettyMessage: string;
};
/** 随机颜色 */
export declare const randomHex: () => string;
/** 清除窗口信息 */
export declare const clearConsole: () => boolean;
