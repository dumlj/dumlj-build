import type { Options } from './types';
/**
 * 创建新的 Pretty 实例
 * @description
 * 主要用于前置名称
 */
export declare function createPretty(name: string): {
    readonly debug: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    readonly ok: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    readonly info: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    readonly warn: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    readonly fail: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
};
