import type { Options } from './types';
/**
 * 创建新的 Pretty 实例
 * @description
 * 主要用于前置名称
 */
export declare const createPretty: (name: string) => {
    debug: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    ok: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    info: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    warn: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
    fail: (message: string | Error, options?: Omit<Options, 'prefix'>) => {
        message: string;
        reason: Error;
        prettyMessage: string;
    };
};
