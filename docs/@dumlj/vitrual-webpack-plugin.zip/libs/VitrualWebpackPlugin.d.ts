import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface VitrualWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 读硬盘 */
    readFromDisk?: boolean;
    /** 写硬盘 */
    writeToDisk?: boolean;
    /** 初始时的文件 */
    files?: Record<string, string>;
    /** 清除文件 */
    empty?: boolean;
    /** 包含 */
    includeDisk?: string[];
}
export declare class VitrualWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected readFromDisk: boolean;
    protected writeToDisk: boolean;
    protected files: Record<string, string>;
    protected includeDisk: string[];
    private originInputFs;
    private originOutputFs;
    static get files(): import("memfs").DirectoryJSON<string>;
    constructor(options?: VitrualWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
