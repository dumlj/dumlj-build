import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface VitrualWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 读硬盘 */
    readFromDisk?: boolean;
    /** 写硬盘 */
    writeToDisk?: boolean;
    /** 初始时的文件 */
    files?: Record<string, string>;
}
export declare class VitrualWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    /** 读硬盘 */
    protected readFromDisk: boolean;
    /** 写硬盘 */
    protected writeToDisk: boolean;
    /** 文件 */
    protected files: Record<string, string>;
    static get files(): import("memfs").DirectoryJSON<string>;
    constructor(options?: VitrualWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
