import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface VitrualWebpackPluginOptions extends SeedWebpackPluginOptions {
    files: Record<string, string>;
}
export declare class VitrualWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected files: Record<string, string>;
    constructor(options?: VitrualWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
