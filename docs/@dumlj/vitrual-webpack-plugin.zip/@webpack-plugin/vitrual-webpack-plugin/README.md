<!-- This file is dynamically generated. please edit in __readme__ -->

# Vitrual Webpack Plugin

Virtual file system plugin.

## INSTALL

```bash
# use npm
$ npm install --dev @dumlj/vitrual-webpack-plugin
# use yarn
$ yarn add --dev @dumlj/vitrual-webpack-plugin
# use pnpm
$ pnpm add @dumlj/vitrual-webpack-plugin -D
```
