/// <reference types="node" />
export interface GitCloneOptions {
    url: string;
    dist: string;
}
/** 获取 Commit 哈希 */
export declare const gitClone: {
    (params_0: GitCloneOptions): Promise<string>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: (params_0: GitCloneOptions) => Promise<string>;
    };
    sync: {
        (params_0: GitCloneOptions): string;
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: (params_0: GitCloneOptions) => string;
        };
    };
};
