/// <reference types="node" />
export interface ProjectInWorkspaces {
    location: string;
    workspaceDependencies: string[];
    mismatchedWorkspaceDependencies: string[];
}
/** 通过 yarn 获取 workspace 信息 */
export declare const yarnWorkspaces: {
    (): Promise<{
        location: string;
        workspaceDependencies: string[];
        mismatchedWorkspaceDependencies: string[];
        name: string;
    }[]>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: () => Promise<{
            location: string;
            workspaceDependencies: string[];
            mismatchedWorkspaceDependencies: string[];
            name: string;
        }[]>;
    };
    sync: {
        (): {
            location: string;
            workspaceDependencies: string[];
            mismatchedWorkspaceDependencies: string[];
            name: string;
        }[];
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: () => {
                location: string;
                workspaceDependencies: string[];
                mismatchedWorkspaceDependencies: string[];
                name: string;
            }[];
        };
    };
};
