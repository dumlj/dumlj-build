import type { Preprocess } from './createExcutor';
export interface Excutor<P extends any[], R> {
    (...params: P): Promise<R>;
    sync(...params: P): R;
}
export declare const preprocessExcutor: (preprocess: Preprocess) => <P extends any[], R>(inExcute: Excutor<P, R>) => {
    (...params: P): Promise<R>;
    sync(...params: P): R;
};
