/// <reference types="node" />
export declare const createYarnExcutor: <C extends import("./createExcutor").Command, R extends import("./createExcutor").Resolve>(command: C, resolv?: R) => {
    (...params: Parameters<C>): Promise<import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: (...params: Parameters<C>) => Promise<import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    };
    sync: {
        (...params: Parameters<C>): import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: (...params: Parameters<C>) => import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        };
    };
};
