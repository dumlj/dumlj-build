<!-- This file is dynamically generated. please edit in __readme__ -->

# Shell Lib

shell 工具库

## INSTALL

```bash
# use npm
$ npm install --dev @dumlj/shell-lib
# use yarn
$ yarn add --dev @dumlj/shell-lib
# use pnpm
$ pnpm add @dumlj/shell-lib -D
```
