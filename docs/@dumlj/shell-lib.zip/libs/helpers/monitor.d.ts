import chokidar from 'chokidar';
export interface MonitorParams {
    command: string;
    argvs: string[];
}
export interface MonitorOptions {
    pattern?: string | string[];
    cwd?: string;
    ignore?: string | string[];
    envs?: Record<string, string>;
    onClose?: () => void;
}
export declare const monitor: (params: MonitorParams, options?: MonitorOptions) => {
    watcher: chokidar.FSWatcher;
    close: () => Promise<void>;
};
