import { type ExecOptions, type ExecSyncOptions } from 'child_process';
/**
 * 执行命令
 * @description
 * 兼容 exec 无法捕获错误
 */
export declare const execute: (command: string, options?: ExecOptions) => Promise<string>;
/**
 * 同步执行命令
 * @description
 * 兼容 exec 无法捕获错误
 */
export declare const executeSync: (command: string, options?: ExecSyncOptions) => string;
