/// <reference types="node" />
/** 判断文件是否忽略 */
export declare const gitDetectIgnore: {
    (file: string | string[]): Promise<string[]>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: (file: string | string[]) => Promise<string[]>;
    };
    sync: {
        (file: string | string[]): string[];
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: (file: string | string[]) => string[];
        };
    };
};
