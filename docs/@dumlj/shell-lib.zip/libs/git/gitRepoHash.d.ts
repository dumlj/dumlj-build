/// <reference types="node" />
/** 克隆项目 */
export declare const gitRepoHash: {
    (): Promise<string>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: () => Promise<string>;
    };
    sync: {
        (): string;
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: () => string;
        };
    };
};
