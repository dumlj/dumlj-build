/// <reference types="node" />
/** 获取 Git 根目录 */
export declare const gitRootPath: {
    (): Promise<string>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: () => Promise<string>;
    };
    sync: {
        (): string;
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: () => string;
        };
    };
};
