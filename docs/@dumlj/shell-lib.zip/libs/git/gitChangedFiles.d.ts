/// <reference types="node" />
/** 获取变更的文件列表 */
export declare const gitChangedFiles: {
    (): Promise<string[]>;
    options: (options?: import("child_process").ExecOptions | undefined) => {
        exec: () => Promise<string[]>;
    };
    sync: {
        (): string[];
        options: (options?: import("child_process").ExecSyncOptions | undefined) => {
            exec: () => string[];
        };
    };
};
