/// <reference types="node" />
/** 获取 Commit 哈希 */
export declare const gitCommitHash: {
    (): Promise<string>;
    options: (options?: import("child_process").ExecOptions | undefined) => {
        exec: () => Promise<string>;
    };
    sync: {
        (): string;
        options: (options?: import("child_process").ExecSyncOptions | undefined) => {
            exec: () => string;
        };
    };
};
