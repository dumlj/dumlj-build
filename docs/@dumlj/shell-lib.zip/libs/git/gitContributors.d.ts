/// <reference types="node" />
/** 克隆项目 */
export declare const gitContributors: {
    (): Promise<{
        name: string;
        email: string | undefined;
    }[]>;
    options: (options?: import("child_process").ExecOptions | undefined) => {
        exec: () => Promise<{
            name: string;
            email: string | undefined;
        }[]>;
    };
    sync: {
        (): {
            name: string;
            email: string | undefined;
        }[];
        options: (options?: import("child_process").ExecSyncOptions | undefined) => {
            exec: () => {
                name: string;
                email: string | undefined;
            }[];
        };
    };
};
