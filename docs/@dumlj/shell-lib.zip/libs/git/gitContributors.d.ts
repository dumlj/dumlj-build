/// <reference types="node" />
/** 克隆项目 */
export declare const gitContributors: {
    (): Promise<{
        name: string;
        email: string;
    }[]>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: () => Promise<{
            name: string;
            email: string;
        }[]>;
    };
    sync: {
        (): {
            name: string;
            email: string;
        }[];
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: () => {
                name: string;
                email: string;
            }[];
        };
    };
};
