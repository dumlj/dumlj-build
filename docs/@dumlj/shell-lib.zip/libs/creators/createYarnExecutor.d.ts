/// <reference types="node" />
export declare const createYarnExecutor: <C extends import("./createExecutor").Command, R extends import("./createExecutor").Resolve>(command: C, resolv?: R) => {
    (...params: Parameters<C>): Promise<import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: (...params: Parameters<C>) => Promise<import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    };
    sync: {
        (...params: Parameters<C>): import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: (...params: Parameters<C>) => import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        };
    };
};
