/// <reference types="node" />
export declare const createGitExecutor: <C extends import("./createExecutor").Command<any[]>, R extends import("./createExecutor").Resolve<Parameters<C>>>(command: C, resolv?: R | undefined) => {
    (...params: Parameters<C>): Promise<import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    options: (options?: import("child_process").ExecOptions | undefined) => {
        exec: (...params: Parameters<C>) => Promise<import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    };
    sync: {
        (...params: Parameters<C>): import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        options: (options?: import("child_process").ExecSyncOptions | undefined) => {
            exec: (...params: Parameters<C>) => import("../utility-types").TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        };
    };
};
