import type { Preprocess } from './createExecutor';
export interface Executor<P extends any[], R> {
    (...params: P): Promise<R>;
    sync(...params: P): R;
}
export declare const preprocessExecutor: (preprocess: Preprocess) => <P extends any[], R>(inExecute: Executor<P, R>) => {
    (...params: P): Promise<R>;
    sync(...params: P): R;
};
