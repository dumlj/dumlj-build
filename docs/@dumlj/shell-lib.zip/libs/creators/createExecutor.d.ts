/// <reference types="node" />
import type { ExecOptions, ExecSyncOptions } from 'child_process';
import type { TrimPromise } from '../utility-types/trim-promise';
interface Payload<P = any> {
    argv?: P;
    async: boolean;
    sync: boolean;
}
/**
 * 预处理
 * @description
 * 可以作为前置检测
 */
export type Preprocess<R = any, P = any> = (execute: () => R, payload?: Payload<P>) => R;
/**
 * 输入的命令行函数
 * @description
 * 因为大部分情况下都是通过命令行改变参数，
 * 因此将命令行设置成函数形式，就可以动态生成执行函数的输入参数
 */
export type Command<P extends any[] = any[]> = (...params: P) => string;
/**
 * 结果处理函数
 * @description
 * 因为命令行返回均为字符串，
 * 所以大部分情况都需要进行数据处理
 */
export type Resolve<P = any> = (stdout: string, payload: Payload<P>) => unknown;
export declare const createExecutor: (preprocess: Preprocess) => <C extends Command<any[]>, R extends Resolve<Parameters<C>>>(command: C, resolv?: R | undefined) => {
    (...params: Parameters<C>): Promise<TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    options: (options?: ExecOptions) => {
        exec: (...params: Parameters<C>) => Promise<TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never>;
    };
    sync: {
        (...params: Parameters<C>): TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        options: (options?: ExecSyncOptions) => {
            exec: (...params: Parameters<C>) => TrimPromise<ReturnType<R>> extends infer P ? unknown extends P ? string : P : never;
        };
    };
};
export {};
