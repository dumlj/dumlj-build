/// <reference types="node" />
/** 获取项目地址 */
export declare const yarnRegistryUrl: {
    (): Promise<string>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: () => Promise<string>;
    };
    sync: {
        (): string;
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: () => string;
        };
    };
};
