export * from './trim-promise';
