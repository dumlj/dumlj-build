/// <reference types="node" />
import type { Package } from '../types';
export declare const npmDeclaredParents: {
    (name: string): Promise<Package[]>;
    options: (options?: import("child_process").ExecOptions | undefined) => {
        exec: (name: string) => Promise<Package[]>;
    };
    sync: {
        (name: string): Package[];
        options: (options?: import("child_process").ExecSyncOptions | undefined) => {
            exec: (name: string) => Package[];
        };
    };
};
