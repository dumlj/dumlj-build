/// <reference types="node" />
export declare const npmLsDependencies: {
    (): Promise<Record<string, import("./types").NpmLsDependency>>;
    options: (options?: import("child_process").ExecOptions) => {
        exec: () => Promise<Record<string, import("./types").NpmLsDependency>>;
    };
    sync: {
        (): Record<string, import("./types").NpmLsDependency>;
        options: (options?: import("child_process").ExecSyncOptions) => {
            exec: () => Record<string, import("./types").NpmLsDependency>;
        };
    };
};
