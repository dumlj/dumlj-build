export declare const npmLsDependencies: () => Promise<Record<string, import("./types").NpmLsDependency>>;
