/// <reference types="node" />
export interface NpmDeclaredDependenciesResp {
    name: string;
    version: string;
}
/**
 * 获取声明的依赖
 * @description
 * 主要用户获取声明过的依赖，未声明的依赖不会返回
 */
export declare const npmDeclaredDependencies: {
    (): Promise<NpmDeclaredDependenciesResp[]>;
    options: (options?: import("child_process").ExecOptions | undefined) => {
        exec: () => Promise<NpmDeclaredDependenciesResp[]>;
    };
    sync: {
        (): NpmDeclaredDependenciesResp[];
        options: (options?: import("child_process").ExecSyncOptions | undefined) => {
            exec: () => NpmDeclaredDependenciesResp[];
        };
    };
};
