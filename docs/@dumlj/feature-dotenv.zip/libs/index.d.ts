/**
 * 解析环境变量文件
 * @param file 环境变量文件
 */
export declare const parseDotEnvFile: (file: string) => Promise<{
    content: string;
    variables: string[];
}>;
/**
 * 查找缺失的环境变量
 * @param files 环境变量文件
 */
export declare const findMissingVariables: (files: string[]) => Promise<{
    variables: Record<string, string[]>;
    files: Record<string, {
        content: string;
    }>;
    missing: {
        file: string;
        variables: string[];
    }[];
}>;
/**
 * 校验环境文件
 * @param files 环境变量文件
 */
export declare const validateDotEnv: (files: string[]) => Promise<string[]>;
