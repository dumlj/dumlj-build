import { SeedWebpackPlugin } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface ZipWebpackPluginOptions {
    /** output file name */
    output?: string;
    /**
     * wrap a folder
     * @example
     * - a.js
     * - b.js
     * set wrap is folder
     * result zip:
     *  - folder
     *    - a.js
     *    - b.js
     */
    wrap?: string;
    /** only output zip file */
    lonely?: boolean;
    /** extra files */
    extras?: Record<string, string>;
}
export declare class ZipWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected output: string;
    protected wrap?: string;
    protected lonely: boolean;
    protected extras: Record<string, string>;
    constructor(options?: ZipWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
