/// <reference types="jest" />
/**
 * mock childProcess
 * @description
 * 无法使用 `jest.mock` 因为 `jest.mock` 必须初始化就执行，
 * 因此 `jest.mock` 必须声明模块名与对应函数，
 * 而函数内用则可以调用其他模块
 */
export declare function mockExec(commands: Record<string, string>): {
    exec: (command: string) => {
        stdout: {
            on: (_: string, fn: (stdout: string) => void) => (stdout: string) => void;
        };
        stderr: {
            on: jest.Mock<any, any, any>;
        };
        on: (_: string, fn: () => void) => () => void;
    };
    execSync: (command: string) => string;
};
