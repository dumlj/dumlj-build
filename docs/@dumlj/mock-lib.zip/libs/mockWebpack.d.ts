import type { Compiler } from 'webpack';
import webpack from 'webpack';
export declare const mockWebpack: (files: Record<string, string>) => (webpackOptions?: webpack.Configuration) => Promise<{
    compiler: Compiler;
    stats: webpack.Stats;
}>;
