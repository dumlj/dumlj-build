import type { Compiler } from 'webpack';
import webpack from 'webpack';
export declare function mockWebpack(files: Record<string, string>): (webpackOptions?: webpack.Configuration) => Promise<{
    compiler: Compiler;
    stats?: webpack.Stats | undefined;
}>;
