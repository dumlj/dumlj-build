/// <reference types="jest" />
export declare function mockLatest(versions: Record<string, Date>): (_: string, fn: (error: Error | null, stdout: string) => void) => {
    kill: jest.Mock<any, any, any>;
};
