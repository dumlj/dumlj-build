/// <reference types="jest" />
export declare const mockLatest: (versions: Record<string, Date>) => (_: string, fn: (error: Error, stdout: string) => void) => {
    kill: jest.Mock<any, any, any>;
};
