<!-- This file is dynamically generated. please edit in __readme__ -->

# Mock Lib

mock 工具库

## INSTALL

```bash
# use npm
$ npm install --dev @dumlj/mock-lib
# use yarn
$ yarn add --dev @dumlj/mock-lib
# use pnpm
$ pnpm add @dumlj/mock-lib -D
```
