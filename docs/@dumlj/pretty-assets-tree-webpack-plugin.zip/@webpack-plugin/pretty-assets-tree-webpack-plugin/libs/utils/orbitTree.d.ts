export interface OrbitNode {
    path: string;
    name: string;
    isFile: boolean;
    children: Set<string | OrbitNode>;
}
export interface ExtraOrbitNode extends OrbitNode {
    siblings: OrbitNode[];
}
export interface TravelOptions {
    ignoreRoot?: boolean;
}
export declare const travelOrbitTree: (tree: OrbitNode, options?: TravelOptions) => (collection: Map<string, OrbitNode>, handle: (node: ExtraOrbitNode, chain: ExtraOrbitNode[]) => void) => void;
export declare const createOrbitNode: (filename: string, isFile: boolean, children?: Array<string | OrbitNode>) => {
    path: string;
    name: string;
    isFile: boolean;
    children: Set<string | OrbitNode>;
};
export declare const mapFileToOrbitTree: (files: string[]) => {
    roots: string[];
    collection: Map<string, OrbitNode>;
    tree: {
        path: string;
        name: string;
        isFile: boolean;
        children: Set<string | OrbitNode>;
    };
};
