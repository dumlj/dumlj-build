export interface Node {
    path: string;
    name: string;
    isFile: boolean;
    children: Set<string | Node>;
}
export interface TravelOptions {
    ignoreRoot?: boolean;
}
export interface ExtraNode extends Node {
    siblings: Node[];
}
export declare const travel: (tree: Node, options?: TravelOptions) => (collection: Map<string, Node>, handle: (node: ExtraNode, chain: ExtraNode[]) => void) => void;
export declare const g: (filename: string, isFile: boolean, children?: Array<string | Node>) => {
    path: string;
    name: string;
    isFile: boolean;
    children: Set<string | Node>;
};
export declare const convertAssetsToTree: (files: string[]) => {
    roots: string[];
    collection: Map<string, Node>;
    tree: {
        path: string;
        name: string;
        isFile: boolean;
        children: Set<string | Node>;
    };
};
