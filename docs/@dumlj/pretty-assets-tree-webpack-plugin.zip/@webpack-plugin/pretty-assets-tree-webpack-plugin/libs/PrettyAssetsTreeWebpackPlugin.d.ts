import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface PrettyAssetsTreeWebpackPluginOptions extends SeedWebpackPluginOptions {
    banner?: string;
    /**
     * pattern of filter out included projects
     * @example
     * ['packages/*']
     */
    include?: string | string[];
    /**
     * pattern of filter out excluded projects
     * @example
     * ['__tests__/*']
     */
    exclude?: string | string[];
}
export declare class PrettyAssetsTreeWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected banner: string;
    protected include: string | string[];
    protected exclude: string | string[];
    constructor(options?: PrettyAssetsTreeWebpackPluginOptions);
    protected applyPrint(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
