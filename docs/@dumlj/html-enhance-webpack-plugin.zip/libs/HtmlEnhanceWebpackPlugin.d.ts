import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type HtmlWebpackPlugin from 'html-webpack-plugin';
import type { Compiler } from 'webpack';
/** Tag 属性 */
export type TagAttrs = Record<string, string | boolean>;
/**
 * Tag 位置
 * @description
 * 这里跟随 HtmlWebpackPlugin 输出，所以只有前后
 */
export type TagLocation = 'prepend' | 'append';
/** Tag 配置 */
export interface TagProps {
    url?: string;
    attrs?: TagAttrs;
    content?: string;
    location?: TagLocation;
}
export interface OverrideAsset {
    /** 额外 Tag */
    assetTags: {
        /** Script Tag */
        scripts: HtmlWebpackPlugin.HtmlTagObject[];
        /** Style Tag */
        styles: HtmlWebpackPlugin.HtmlTagObject[];
        /** Meta Tag */
        meta: HtmlWebpackPlugin.HtmlTagObject[];
    };
    /** 公共路径 */
    publicPath: string;
    /** 输出名称 */
    outputName: string;
    /** HtmlWebpackPlugin */
    plugin: HtmlWebpackPlugin;
}
export type OverrideAssetCallback = (asset: OverrideAsset) => OverrideAsset;
export interface InjectTagsOptions {
    /** Script Tag 配置集合 */
    scriptTags?: Array<string | TagProps>;
    /** Link Tag 配置集合 */
    styleTags?: Array<string | TagProps>;
    /** Meta Tag 配置集合 */
    metaTags?: Array<Omit<TagProps, 'url' | 'content'>>;
}
export interface InjectVariablesOptions {
    /** 存放环境变量的全局变量 */
    globalThis?: string;
    /** 存放环境变量的全局变量属性名称 */
    globalThisProp?: string;
    /** Script Tag ID */
    scriptTagId?: string;
}
/** 插件必要参数 */
export interface HtmlEnhanceWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 输出的 HTML 文件名 */
    htmlNS: string;
    /**
     * HtmlWebpackPlugin 插件
     * 因为版本原因，所以请导入所用的 HtmlWebpackPlugin
     */
    HtmlWebpackPlugin: typeof HtmlWebpackPlugin;
    /** HtmlWebpackPlugin 实例 */
    htmlWebpackPluginInstance: HtmlWebpackPlugin;
}
export declare class HtmlEnhanceWebpackPlugin extends SeedWebpackPlugin<HtmlEnhanceWebpackPluginOptions> {
    static PLUGIN_NAME: string;
    protected overrides: Set<OverrideAssetCallback>;
    htmlNS: string;
    htmlWebpackPluginInstance: HtmlWebpackPlugin;
    HtmlWebpackPlugin: typeof HtmlWebpackPlugin;
    constructor(options: HtmlEnhanceWebpackPluginOptions);
    injectVariables(envs: Record<string, string>, options?: InjectVariablesOptions): void;
    injectTags(options: InjectTagsOptions): void;
    /** 统一 Tag 属性 */
    protected unifiedTagProps(props: string | TagProps, defaultAttrs?: TagAttrs): TagProps;
    /** 替换静态资源 */
    overrideAssets(override: OverrideAssetCallback): void;
    /** 将 HtmlWebpackPlugin 拆解成 htmlNS, HtmlWebpackPlugin, htmlWebpackPluginInstance */
    protected dismantleHtmlWebpackPlugin(params: Partial<Pick<HtmlEnhanceWebpackPluginOptions, 'htmlNS' | 'HtmlWebpackPlugin' | 'htmlWebpackPluginInstance'>>): {
        htmlNS: string;
        HtmlWebpackPlugin: typeof import("html-webpack-plugin");
        htmlWebpackPluginInstance: HtmlWebpackPlugin;
    };
    apply(compiler: Compiler): void;
}
