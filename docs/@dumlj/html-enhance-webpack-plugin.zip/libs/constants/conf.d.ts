/** Global variables that store environment variables */
export declare const GLOBAL_TARGET = "Object";
