/** 环境变量 */
export declare const makeEnvTagRenderer: (globalThisProp: string, globalThis?: string) => ([]: TemplateStringsArray, value: string) => string;
