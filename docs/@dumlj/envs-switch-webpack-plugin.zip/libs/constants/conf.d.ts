/** Global variables that store environment variables */
export declare const GLOBAL_TARGET = "Object";
/** 脚本路径 */
export declare const SCRIPT_SRC: string;
