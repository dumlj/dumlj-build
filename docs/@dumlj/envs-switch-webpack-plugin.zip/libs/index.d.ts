import { SeedWebpackPlugin } from '@dumlj/seed-webpack-plugin';
import { type DynamicEnvsWebpackPluginOptions } from '@dumlj/dynamic-envs-webpack-plugin';
import type { Compiler, WebpackPluginInstance } from 'webpack';
export interface EnvsSwitchWebpackPluginOptions extends DynamicEnvsWebpackPluginOptions {
    /** output file */
    filename?: string;
    /** 额外环境变量 */
    envs?: Record<string, any>;
    /**
     * 跳过 Dev 模式对比
     * @description
     * 默认为 false
     */
    skipCompareDevMode?: boolean;
    /** 环境变量文件夹, 默认为 dotenv */
    dotenvFolder?: string;
    /** 文件夹文件格式, 默认为 $1.env, $1 为环境名 */
    dotenvFormater?: string;
    /** dotenv 文件, 默认为 .env */
    dotenvFilename?: string;
}
export declare class EnvsSwitchWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected filename: string;
    protected output?: string;
    protected hash?: string;
    protected envs: Record<string, any>;
    protected skipCompareDevMode?: boolean;
    protected scriptPath?: string;
    protected dotenvFolder: string;
    protected dotenvFormater: string;
    protected dotenvFilename: string;
    protected globalThisProp?: string;
    protected guid: string;
    protected variablesInEnvironments: Record<string, Record<string, string>>;
    constructor(options?: EnvsSwitchWebpackPluginOptions);
    /** compare difference dotenv files */
    applyCompare(compiler: Compiler): void;
    /** inject envs into entry */
    applyInjectEnvs(compiler: Compiler): void;
    protected collectDotenv(folder: string): Record<string, Record<string, string>> | undefined;
    /** generate switch script */
    applySwitchScript(compiler: Compiler): void;
    protected spwanCompile(compiler: Compiler, plugins: WebpackPluginInstance[]): Promise<void>;
    apply(compiler: Compiler): void;
}
