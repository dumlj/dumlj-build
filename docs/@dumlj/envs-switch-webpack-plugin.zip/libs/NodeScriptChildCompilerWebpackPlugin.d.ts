import { type Compiler, type Compilation } from 'webpack';
import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
export declare class NodeScriptChildCompilerWebpackPlugin extends SeedWebpackPlugin {
    protected mainCompilaction: Compilation;
    constructor(mainCompilaction: Compilation, options?: SeedWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
