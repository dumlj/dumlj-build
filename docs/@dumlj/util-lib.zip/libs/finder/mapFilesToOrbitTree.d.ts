export declare const mapFilesToOrbitTree: (files: string[]) => {
    path: string[];
    value: string;
    isLatest: boolean;
    children: Set<import("../orbit").OrbitNode>;
};
