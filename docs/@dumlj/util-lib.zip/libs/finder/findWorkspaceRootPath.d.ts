export interface FindWorkspaceRootPathOptions {
    paths?: string[];
}
export declare function findWorkspaceRootPath(options?: FindWorkspaceRootPathOptions): Promise<string | undefined>;
