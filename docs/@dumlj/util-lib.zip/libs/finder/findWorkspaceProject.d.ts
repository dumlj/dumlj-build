export interface Project {
    name: string;
    version: string;
    description: string;
    location: string;
    dependencies: string[];
    workspaceDependencies: string[];
    isPrivate: boolean;
}
export interface ProjectGraph extends Project {
    graph?: ProjectGraph[];
}
export interface FindWorkspaceProjectOptions {
    /** project pattern in workspace (default get workspace settings from package.json) */
    pattern?: string[];
    /** get datas from cache if projects have been cached (default true) */
    fromCache?: boolean;
    /** workspace root path (default process.cwd()) */
    cwd?: string;
}
/** find projects from workspace project */
export declare const findWorkspaceProject: (options?: FindWorkspaceProjectOptions) => Promise<Project[]>;
