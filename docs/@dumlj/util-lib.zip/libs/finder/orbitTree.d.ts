export interface OrbitNode {
    path: string;
    name: string;
    isFile: boolean;
    children?: Set<OrbitNode>;
}
export interface ExtraOrbitNode extends OrbitNode {
    siblings: OrbitNode[];
}
export interface TravelOptions {
    ignoreRoot?: boolean;
}
export declare const travelOrbitTree: (tree: OrbitNode, options?: TravelOptions) => (handle: (node: ExtraOrbitNode, chain: ExtraOrbitNode[]) => void) => void;
export declare const createOrbitNode: (filename: string, isFile: boolean, children?: OrbitNode[]) => {
    path: string;
    name: string;
    isFile: boolean;
    children: Set<OrbitNode>;
};
export declare const mapFileToOrbitTree: (files: string[]) => {
    path: string;
    name: string;
    isFile: boolean;
    children: Set<OrbitNode>;
};
export declare const detectLatest: (node: ExtraOrbitNode) => boolean;
export interface OrbitTreeString {
    orbit: string;
    file: string;
    isFile: boolean;
}
export declare const stringifyOrbitTree: (tree: OrbitNode) => OrbitTreeString[];
