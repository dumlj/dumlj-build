export interface RegisterCacheOptions {
    /** 过期时间 */
    expire?: number;
}
export interface ReadOptions {
    /** 获取后删除 */
    remove?: boolean;
}
/** 注册缓存 */
export declare const registerCache: <T>(scope?: string, options?: RegisterCacheOptions) => {
    write: (name: string, data: T) => Promise<void>;
    read: (name: string, options?: ReadOptions) => Promise<T | undefined>;
    remove: (name: string) => Promise<void>;
};
