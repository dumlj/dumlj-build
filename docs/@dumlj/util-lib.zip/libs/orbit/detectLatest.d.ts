import type { ExtraOrbitNode } from './types';
export declare const detectLatest: (node: ExtraOrbitNode) => boolean;
