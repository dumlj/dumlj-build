import type { OrbitNode, ExtraOrbitNode } from './types';
export interface TravelOptions {
    ignoreRoot?: boolean;
}
export declare const travelOrbitTree: (tree: OrbitNode, options?: TravelOptions) => (handle: (node: ExtraOrbitNode, chain: ExtraOrbitNode[]) => void) => void;
