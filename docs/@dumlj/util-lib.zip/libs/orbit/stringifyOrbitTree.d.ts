import type { OrbitNode } from './types';
export interface OrbitTreeString {
    orbit: string;
    content: string[];
    isLatest: boolean;
}
export declare const stringifyOrbitTree: (tree: OrbitNode) => OrbitTreeString[];
