import type { OrbitNode } from './types';
export declare const createOrbitNode: (nodes: string[], isLatest: boolean, childs?: OrbitNode[]) => {
    path: string[];
    value: string;
    isLatest: boolean;
    children: Set<OrbitNode>;
};
