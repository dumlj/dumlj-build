import type { OrbitNode } from './types';
export declare function mapPathsToOrbitTree(paths: string[][]): {
    path: string[];
    value: string;
    isLatest: boolean;
    children: Set<OrbitNode>;
} | undefined;
