import type { OrbitNode } from './types';
export declare const mapPathsToOrbitTree: (paths: string[][]) => {
    path: string[];
    value: string;
    isLatest: boolean;
    children: Set<OrbitNode>;
};
