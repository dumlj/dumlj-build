/** 分割字符 */
export declare const DIVIDER_CHAR = "#";
