export type Processify<T extends Record<string, any>> = {
    [K in keyof T]: K extends string ? Record<`process.env.${K}`, T[K]> : never;
};
export interface DefenvResp<T extends Record<string, any>> {
    raw: T;
    stringified: Processify<T>;
}
export type TemplateRenderer = ([]: TemplateStringsArray, key: string, value: string) => string;
export interface DefenvOptions {
    prefix?: string;
}
export declare const defenv: <T extends Record<string, string> = Record<string, string>>(render: TemplateRenderer, options?: DefenvOptions) => (variables: Record<string, any>) => DefenvResp<T>;
