export declare const guid: () => any;
