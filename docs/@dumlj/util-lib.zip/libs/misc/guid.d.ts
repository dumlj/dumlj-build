export declare const ids: Set<string>;
export declare const guid: () => any;
