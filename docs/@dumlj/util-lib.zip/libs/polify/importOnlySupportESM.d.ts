export declare const importOnlySupportESM: <R = any>(module: string) => Promise<R>;
