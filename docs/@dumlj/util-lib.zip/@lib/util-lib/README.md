<!-- This file is dynamically generated. please edit in __readme__ -->

# Util Lib

util 工具库

## INSTALL

```bash
# use npm
$ npm install --dev @dumlj/util-lib
# use yarn
$ yarn add --dev @dumlj/util-lib
# use pnpm
$ pnpm add @dumlj/util-lib -D
```
