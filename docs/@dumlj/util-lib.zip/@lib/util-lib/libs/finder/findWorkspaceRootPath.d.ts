interface FindWorkspaceRootPathOptions {
    paths?: string[];
}
export declare const findWorkspaceRootPath: (options?: FindWorkspaceRootPathOptions) => Promise<string>;
export {};
