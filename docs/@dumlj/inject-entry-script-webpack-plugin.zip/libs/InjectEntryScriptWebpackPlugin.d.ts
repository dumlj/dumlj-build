import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface InjectEntryScriptWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 位于另一个入口文件之后 */
    after?: string;
}
export declare class InjectEntryScriptWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected scriptPath: string;
    protected after?: string;
    constructor(scriptPath: string, options?: InjectEntryScriptWebpackPluginOptions);
    /** prepend or append script to all entries */
    protected pushScriptToEntries(scriptPath: string, options?: InjectEntryScriptWebpackPluginOptions): <T>(entries: T) => T;
    applyInject(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
