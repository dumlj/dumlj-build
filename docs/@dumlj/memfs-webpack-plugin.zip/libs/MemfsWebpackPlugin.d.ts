import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface MemfsWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 读硬盘 */
    readFromDisk?: boolean;
    /** 写硬盘 */
    writeToDisk?: boolean;
    /** 初始时的文件 */
    files?: Record<string, string>;
    /** 清除文件 */
    empty?: boolean;
    /** 包含 */
    include?: string[];
    /** 不包含 */
    exclude?: string[];
}
export declare class MemfsWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected readFromDisk: boolean;
    protected writeToDisk: boolean;
    protected files: Record<string, string>;
    protected include: string[];
    protected exclude: string[];
    private originInputFs;
    private originOutputFs;
    static get files(): import("memfs").DirectoryJSON<string>;
    constructor(options?: MemfsWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
