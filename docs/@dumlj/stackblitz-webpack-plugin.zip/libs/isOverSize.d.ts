export declare function isOverSize(size: number): boolean;
