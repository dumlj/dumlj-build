export declare const ID: string;
export declare const WS_DIR: string;
export declare const BOOTSTRAP_EVENT_TYPE: string;
export declare const PKG_FILE = "package.json";
export declare const PNPM_WORKSPACE_FILE = "pnpm-workspace.yaml";
export declare const STACKBLITZ_RC = ".stackblitzrc";
export { K, M, OVERSIZE_MESSAGE } from '../constants';
