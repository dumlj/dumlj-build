import type { Class } from 'utility-types';
export declare function defineWebComponent(tag: string, Component: Class<HTMLElement> & {
    readonly inheritTag?: string;
}): (_: TemplateStringsArray, __1_0: Record<string, any>, __1_1: string) => string;
