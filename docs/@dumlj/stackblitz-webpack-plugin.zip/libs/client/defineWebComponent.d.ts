import type { Class } from 'utility-types';
export declare const defineWebComponent: (tag: string, Component: Class<HTMLElement>) => void;
