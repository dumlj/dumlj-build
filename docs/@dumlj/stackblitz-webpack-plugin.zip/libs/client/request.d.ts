export interface RequestProcess {
    loaded: number;
    process: number;
    total: number;
}
export interface RequestOptions {
    onProcess(process: RequestProcess): void;
}
export declare function request(url: string, options?: RequestOptions): Promise<Uint8Array | undefined>;
