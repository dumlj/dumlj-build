export declare const style: (_: TemplateStringsArray, stylesheets: Record<string, Record<string, string | number>>) => string;
export declare const tag: (tagName: TemplateStringsArray, __1_0: Record<string, string>, __1_1?: string | number) => string;
