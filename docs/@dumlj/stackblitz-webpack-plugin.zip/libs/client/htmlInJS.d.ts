export declare function style(_: TemplateStringsArray, stylesheets: Record<string, Record<string, string | number>>): string;
export declare function tag(tagName: TemplateStringsArray, ...[props, children]: [Record<string, string>, (string | number)?]): string;
