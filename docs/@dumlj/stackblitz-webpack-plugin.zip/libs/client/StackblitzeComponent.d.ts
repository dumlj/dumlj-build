import { type VM, type EmbedOptions } from '@stackblitz/sdk';
export interface MANIFEST_ASSETS_STATS {
    examples: Record<string, string[]>;
    tarballs: Record<string, string[]>;
    extras?: [string, string][];
}
export declare class StackblitzeComponent extends HTMLElement {
    protected MANIFEST_CACHE: MANIFEST_ASSETS_STATS;
    protected TARBALL_CACHE: Record<string, Map<string, string>>;
    protected vm: VM;
    constructor();
    connectedCallback(): Promise<void>;
    attributeChangedCallback(name: string, prevValue: string, nextValue: string): Promise<void>;
    disconnectedCallback(): void;
    protected loadManifest(): Promise<MANIFEST_ASSETS_STATS>;
    protected concatUnit8Array(...uint8: Uint8Array[]): Promise<Uint8Array>;
    protected downloadTarball(project: string): Promise<[string, string][]>;
    protected extractTarballs(name: string): Promise<Map<string, string>>;
    protected buildProject(name: string): Promise<{
        template: "node";
        title: any;
        description: any;
        files: Record<string, string>;
    }>;
    protected activeProject(name: string): (container: string | HTMLElement, options?: EmbedOptions) => Promise<VM>;
    protected embed(name: string): Promise<VM>;
}
