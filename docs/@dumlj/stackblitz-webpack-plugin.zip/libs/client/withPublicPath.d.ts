export declare const withPublicPath: (url: string) => string;
