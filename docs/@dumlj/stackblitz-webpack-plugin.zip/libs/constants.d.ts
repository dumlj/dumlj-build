/** custom element tag */
export declare const HTML_TAG = "dumlj-stackblitz";
/**
 * ignore files
 * @description
 * pattern of path
 */
export declare const IGNORED_PATTERNS: string[];
