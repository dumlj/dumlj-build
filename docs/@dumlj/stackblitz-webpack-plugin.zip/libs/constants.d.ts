/** custom element tag */
export declare const HTML_TAG = "dumlj-stackblitz";
/**
 * ignore files
 * @description
 * pattern of path
 */
export declare const IGNORED_PATTERNS: string[];
export declare const K = 1024;
export declare const M: number;
export declare const OVERSIZE_MESSAGE = "Please make sure that the source code size is less than \"1Mb\".\nUsing \"ignore\" option to filter unnecessary files.";
