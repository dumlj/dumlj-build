import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import { type Project } from '@dumlj/util-lib';
import JSZip from 'jszip';
import type { Compiler } from 'webpack';
export interface ExampleInfo {
    rootPath: string;
    examples: Record<string, string[]>;
    projects: Set<Project>;
}
export interface Stats {
    name: string;
    files: string[];
    zip: JSZip;
}
export interface StackblitzWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** the name of manifest */
    manifest?: string;
    /** ignore file pattern */
    ignored?: string[];
    /** extra files */
    files?: string[];
    /** determine if project is a demo (default name matches `*-example`) */
    test?: (name: string, project: Project) => boolean;
    /** custom html tag (default <dumlj-stackblitz></dumlj-stackblitz>) */
    customElement?: string;
}
export declare class StackblitzWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected manifest: string;
    protected ignored: string[];
    protected files: string[];
    protected test?: (name: string, project: Project) => boolean;
    protected customElement?: string;
    constructor(options?: StackblitzWebpackPluginOptions);
    /** collect project and zip tarballs */
    applyTarball(compiler: Compiler): void;
    /** inject client script */
    applyClient(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
