import { HtmlEnhanceWebpackPlugin, type HtmlEnhanceWebpackPluginOptions } from '@dumlj/html-enhance-webpack-plugin';
import type { Compiler } from 'webpack';
export interface HtmlInjectEnvsWebpackPluginOptions extends HtmlEnhanceWebpackPluginOptions {
    /** 存放环境变量的全局变量 */
    globalThis?: string;
    /** 存放环境变量的全局变量属性名称 */
    globalThisProp?: string;
    /** Script Tag ID */
    scriptTagId?: string;
}
export declare class HtmlInjectEnvsWebpackPlugin extends HtmlEnhanceWebpackPlugin {
    static PLUGIN_NAME: string;
    variables: Record<string, any>;
    globalThis?: string;
    globalThisProp?: string;
    scriptTagId?: string;
    constructor(envs: Record<string, any>, options?: HtmlInjectEnvsWebpackPluginOptions);
    applyInjectEnvs(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
