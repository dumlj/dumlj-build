import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface ChromeContentScript {
    matches?: string[];
    css?: string[];
    js?: string[];
    run_at?: string;
}
export interface WebAccessibleResource {
    resources: string[];
    matches: string[];
}
export interface ChromeManifest {
    name: string;
    description: string;
    version: string;
    manifest_version: 3;
    background?: {
        service_worker?: string;
    };
    action?: {
        default_popup: string;
    };
    content_scripts?: ChromeContentScript[];
    web_accessible_resources?: WebAccessibleResource[];
}
export interface CrxManifestWebpackPluginOptions extends SeedWebpackPluginOptions {
    /** 后台 JS 文件 */
    background?: string;
    /** Popup HTML 文件 */
    popup?: string;
    /** 注入的 JS 文件 */
    contentScript?: string;
    /** 基础 Manifest */
    manifest?: ChromeManifest;
}
export declare class CrxManifestWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected background: string;
    protected popup: string;
    protected contentScript: string;
    protected manifest: ChromeManifest;
    constructor(options?: CrxManifestWebpackPluginOptions);
    apply(compiler: Compiler): void;
}
