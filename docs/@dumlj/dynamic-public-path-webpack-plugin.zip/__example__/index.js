// eslint-disable-next-line no-console
console.log(process.env.WS)

document.body.innerHTML = `Open browser console.<br/>process.env.WS is ${process.env.WS}.<br/><a href="javascript:history.back()">Back</a>`
