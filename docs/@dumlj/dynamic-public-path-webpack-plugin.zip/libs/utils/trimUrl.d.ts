export declare const trimUrlPathStart: (url: string) => string;
export declare const trimUrlPathEnd: (url: string) => string;
export declare const trimUrlPath: (url: string) => string;
