export declare const htmlify: (name: string) => string;
