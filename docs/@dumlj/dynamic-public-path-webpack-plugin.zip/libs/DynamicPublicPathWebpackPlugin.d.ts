import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import { type Options as HtmlWebpackPluginOptions } from 'html-webpack-plugin';
import type { Compiler } from 'webpack';
export type PublicPaths = Record<string, string | {
    /** 公共路径 */
    publicPath: string;
    /** 额外环境变量 */
    envs?: Record<string, string>;
}>;
export interface DynamicPublicPathWebpackPluginOptions extends SeedWebpackPluginOptions, HtmlWebpackPluginOptions {
    scriptPath?: string;
}
export declare class DynamicPublicPathWebpackPlugin extends SeedWebpackPlugin<DynamicPublicPathWebpackPluginOptions> {
    static PLUGIN_NAME: string;
    protected publicPath: string;
    protected publicPaths: Record<string, string>;
    protected envs: Set<string>;
    protected variables: Record<string, Record<string, string>>;
    protected scriptPath: string;
    constructor(publicPaths?: PublicPaths, options?: DynamicPublicPathWebpackPluginOptions);
    applyPublicPath(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
