import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import { type TagProps } from '@dumlj/html-enhance-webpack-plugin';
import { type Options as HtmlWebpackPluginOptions } from 'html-webpack-plugin';
import type { Compiler } from 'webpack';
export type PublicPaths = Record<string, string | {
    /** 公共路径 */
    publicPath: string;
    /** 额外环境变量 */
    envs?: Record<string, string>;
    /** meta标签 */
    metaTags?: Array<Omit<TagProps, 'url' | 'content'>>;
    /** 脚本标签 */
    scriptTags?: Array<string | TagProps>;
    /** 样式标签 */
    styleTags?: Array<string | TagProps>;
}>;
export interface DynamicPublicPathWebpackPluginOptions extends SeedWebpackPluginOptions, HtmlWebpackPluginOptions {
    scriptPath?: string;
}
export declare class DynamicPublicPathWebpackPlugin extends SeedWebpackPlugin<DynamicPublicPathWebpackPluginOptions> {
    static PLUGIN_NAME: string;
    protected publicPath: string;
    /** file/publicPath */
    protected publicPaths: Map<string, string>;
    /** file/env */
    protected variables: Map<string, Record<string, string>>;
    protected scriptPath: string;
    protected metaTags: Map<string, Array<Omit<TagProps, 'url' | 'content'>>>;
    protected scriptTags: Map<string, Array<string | TagProps>>;
    protected styleTags: Map<string, Array<string | TagProps>>;
    constructor(publicPaths?: PublicPaths, options?: DynamicPublicPathWebpackPluginOptions);
    applyPublicPath(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
