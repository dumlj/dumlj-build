/** modify __webpack_public_path__ module */
export declare const PUBLIC_PATH_MODULE_SCRIPT_PATH: string;
