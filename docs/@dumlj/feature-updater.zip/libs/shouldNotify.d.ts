export interface ShouldNotifyOptions {
    /**
     * 过期时间(单位毫秒)
     * @description
     * 默认为 1 天
     * 当前时间减去上一次告警时间必须大于该时间
     * 才能再告警
     */
    expire?: number;
}
export declare const shouldNotify: (token: string, options?: ShouldNotifyOptions) => Promise<boolean>;
