import { type LatestOptions as FindLatestVersionOptions } from './utils/latest';
export interface ShouldUpdateOptions extends FindLatestVersionOptions {
    /**
     * 最后的版本号
     * @description
     * 不传默认读取远程
     * 一般仅用于调试
     */
    latestVersion?: string;
}
/** 检测包需要更新 */
export declare function shouldUpdate(name: string, options?: ShouldUpdateOptions): Promise<{
    name: string;
    updateType: string | boolean;
    version: string;
    latestVersion: string;
    shouldUpdate: boolean;
}>;
