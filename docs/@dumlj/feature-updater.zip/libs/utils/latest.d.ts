import { type DiffValues } from './diff';
/** 最后版本 */
export interface LatestOptions {
    /** 对比的版本号 */
    includes?: DiffValues[];
    /** 需要对比的版本 */
    compareVer?: string;
    /** 设置发布后经过指定时间段后才执行 */
    sincePublish?: number;
    /** 超时时间 (单位：毫秒，默认：3秒)  */
    timeout?: number;
}
/** 获取最后版本 */
export declare const latest: (name: string, options?: LatestOptions) => Promise<string>;
