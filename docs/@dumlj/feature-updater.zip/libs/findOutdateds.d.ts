import { type LatestOptions as FindLatestVersionOptions } from './utils/latest';
export interface FindOutdatedsOptions extends Omit<FindLatestVersionOptions, 'compareVersion'> {
    /** 依赖名 */
    name?: string;
    /**
     * 最后的版本号
     * @description
     * 不传默认读取远程
     * 一般仅用于调试
     */
    latestVersion?: string;
}
/** 查找过期模块 */
export declare const findOutdateds: (options?: FindOutdatedsOptions) => Promise<{
    name: string;
    updateType: string | boolean;
    version: string;
    latestVersion: string;
    shouldUpdate: boolean;
}[]>;
