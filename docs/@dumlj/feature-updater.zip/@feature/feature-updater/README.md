<!-- This file is dynamically generated. please edit in __readme__ -->

# Feature Updater

更新程序

## INSTALL

```bash
# use npm
$ npm install --dev @dumlj/feature-updater
# use yarn
$ yarn add --dev @dumlj/feature-updater
# use pnpm
$ pnpm add @dumlj/feature-updater -D
```
