export declare const diff: (target: string, compare: string) => false | "premajor" | "major" | "preminor" | "minor" | "prepatch" | "patch";
export type DiffValues = ReturnType<typeof diff>;
