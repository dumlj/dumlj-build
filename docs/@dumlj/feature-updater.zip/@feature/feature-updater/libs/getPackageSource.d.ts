export declare const getPackageSource: () => Promise<PackageSource>;
