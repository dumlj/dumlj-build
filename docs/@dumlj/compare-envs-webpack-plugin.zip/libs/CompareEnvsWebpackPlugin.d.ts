import { SeedWebpackPlugin, type SeedWebpackPluginOptions } from '@dumlj/seed-webpack-plugin';
import type { Compiler } from 'webpack';
export interface CompareEnvsWebpackPluginOptions extends SeedWebpackPluginOptions {
    /**
     * 对比其他环境变量文件
     * @description
     * 此部分环境变量会作为 `{ [key]: '' }` 存储到环境变量中
     */
    compare?: string | string[];
    /**
     * 跳过 Dev 模式对比
     * @description
     * 默认为 false
     */
    skipCompareDevMode?: boolean;
}
export declare class CompareEnvsWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    protected compare: string | string[];
    protected skipCompareDevMode: boolean;
    constructor(options?: CompareEnvsWebpackPluginOptions);
    /** 查找 dotenv 文件 */
    protected lookupDotenvFiles(pattern: string | string[], context?: string): Promise<string[]>;
    applyCompare(compiler: Compiler): void;
    apply(compiler: Compiler): void;
}
