import type { Compiler } from 'webpack';
import { SeedWebpackPlugin } from './SeedWebpackPlugin';
/**
 * 版本过期通知插件
 * @description
 * 与 SeedWebpackPlugin 相互引用
 * - OutdatedWebpackPlugin 继承 SeedWebpackPlugin
 * - SeedWebpackPlugin 在执行时才会调用 OutdatedWebpackPlugin
 */
export declare class OutdatedWebpackPlugin extends SeedWebpackPlugin {
    static PLUGIN_NAME: string;
    /** 是否已经检测过 */
    protected hasChecked?: boolean;
    /** 版本过期警告 */
    yellOutdateds(): Promise<void>;
    apply(compiler: Compiler): Promise<void>;
}
