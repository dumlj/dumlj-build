## BACKGROUND

Webpack 插件开发存在大量重复流程，因此所有 `@dumlj/*-webpack-plugin` 插件均继承该模块。
