declare const __webpack_module__: {
  id: string
  parents: string[]
}
