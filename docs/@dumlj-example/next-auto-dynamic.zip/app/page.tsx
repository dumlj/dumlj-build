import SSR from '../components/SSR'

export default function Index() {
  return (
    <div>
      Hello World <SSR />
    </div>
  )
}
