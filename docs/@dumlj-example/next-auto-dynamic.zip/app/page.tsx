import SSR from '../components/SSR'

export default function Index() {
  return <SSR />
}
