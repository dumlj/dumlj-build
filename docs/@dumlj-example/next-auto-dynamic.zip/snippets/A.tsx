'use client'

export default function A() {
  return <div>A</div>
}
