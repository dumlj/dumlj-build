'use client'

export default function B() {
  return <div>B</div>
}
