// eslint-disable-next-line no-console
console.log(process.env.APP_ENV)

// open the second DynamicEnvsWebpackPlugin
// eslint-disable-next-line no-console
// typeof process !== 'undefined' && console.log(process.env.APP_ENV_ANOTHER_KEY)
