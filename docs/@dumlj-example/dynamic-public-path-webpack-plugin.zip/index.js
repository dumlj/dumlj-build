// eslint-disable-next-line no-console
console.log(process.env.WS)
